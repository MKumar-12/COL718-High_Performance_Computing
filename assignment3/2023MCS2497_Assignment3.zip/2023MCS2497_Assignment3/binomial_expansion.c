// Function to compute the binomial expansion (a + x) ^ n

#include <stdio.h>
#include <math.h>

#define ll long long 

ll fact(int n) {
    ll res = 1;
    for(int i = 2; i <= n; i++)
        res *= i;

    return res;
}

ll nCr(int n, int r) {
    if(r > n - r) 
        r = n - r;          // Use symmetry property nCr = nC(n-r)

    return fact(n) / (fact(r) * fact(n - r));
}

ll compute_expansion(int a, int x, int n) {
    ll res = 0;
    for(int i = 0; i <= n; i++) 
        res += nCr(n, i) * pow(a, i) * pow(x, n - i); 

    return res;
}


int main() {
    int a, x, n;
    printf("Enter values for a, x, n :\t");
    scanf("%d %d %d", &a, &x, &n);

    printf("Value for expansion (%d + %d)^%d :    %lld", a, x, n, compute_expansion(a, x, n));
    return 0;
}